import Entidad.Fraccion;
import Servicio.FraccionServicio;

public class Main {
    public static void main(String[] args) {

        Fraccion fraccion = new Fraccion();
        FraccionServicio fraccionServicio = new FraccionServicio();



        fraccion = fraccionServicio.crearFraccion();
        fraccionServicio.sumar(fraccion);
        fraccionServicio.restar(fraccion);
        fraccionServicio.multiplicar(fraccion);
        fraccionServicio.dividir(fraccion);

    }
}